**<span style="color:#56adda">0.1.0</span>**
- New layout to try and make better use of space

**<span style="color:#56adda">0.0.12</span>**
- Correct spacing between the bars on the size charts
- Reduce the height of the top chart area

**<span style="color:#56adda">0.0.11</span>**
- File Size charts now support the dark theme

**<span style="color:#56adda">0.0.10</span>**
- Initial version of dark mode support

**<span style="color:#56adda">0.0.9</span>**
- Update DataTables plugin in preparation of supporting dark mode

**<span style="color:#56adda">0.0.8</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.7</span>**
- Fix issue with number formatting
- Add support for parsing data for tasks processed with remote workers

**<span style="color:#56adda">0.0.6</span>**
- Remove migrations of legacy Unmanic historic data as it still causes intermittent issues
- More improvements to plugin's database connection

**<span style="color:#56adda">0.0.5</span>**
- Improvements to plugin's database connection

**<span style="color:#56adda">0.0.4</span>**
- Fix issue where the Plugin's database was being locked by multiple workers attempting to update at the same time

**<span style="color:#56adda">0.0.3</span>**
- Fix exception and rollback of DB transaction.

**<span style="color:#56adda">0.0.2</span>**
- Set initial flow priority to high

**<span style="color:#56adda">0.0.1</span>**
- Initial version
