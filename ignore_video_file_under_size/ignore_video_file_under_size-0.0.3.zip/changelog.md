
**<span style="color:#56adda">0.0.3</span>**
- add option to read duration from format section of ffprobe output

**<span style="color:#56adda">0.0.2</span>**
- Skip checking non-video files

**<span style="color:#56adda">0.0.1</span>**
- Initial version
